import './globals.css';
import React from 'react';
import Nav from './components/Nav';

export const metadata = {
  title: 'Site com Auth e Planos',
  description: 'Exemplo de Next.js com autenticação e planos'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <Nav />
        <main>{children}</main>
      </body>
    </html>
  );
}
