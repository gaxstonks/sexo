import React from 'react';
export default function Pricing(){
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Planos</h1>
      <p className="mt-2">Escolha um plano para liberar acesso aos downloads.</p>
      <p className="mt-4">Exemplo: botão que redirecionaria ao checkout do Stripe.</p>
    </div>
  );
}
