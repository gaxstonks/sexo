'use client';
import React, { useState } from 'react';
import AuthModal from './components/AuthModal';

export default function Home() {
  const [showAuth, setShowAuth] = useState(true);
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Bem-vindo</h1>
      <p className="mt-2">Site com autenticação e sistema de planos.</p>
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </div>
  );
}
