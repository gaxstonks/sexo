'use client';
import React, { useState } from 'react';
import { signIn } from 'next-auth/react';

export default function LoginForm(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');

  async function handleSubmit(e: React.FormEvent){
    e.preventDefault();
    setMsg('Entrando...');
    const res = await signIn('credentials', { redirect: false, email, password });
    if (res && (res as any).ok) {
      setMsg('Logado! Redirecionando...');
      window.location.href = '/dashboard';
    } else {
      setMsg('Erro ao autenticar');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input className="w-full border p-2" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <input className="w-full border p-2" placeholder="Senha" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
      <button className="w-full bg-green-600 text-white p-2 rounded">Entrar</button>
      {msg && <p className="text-sm mt-2">{msg}</p>}
    </form>
  );
}
