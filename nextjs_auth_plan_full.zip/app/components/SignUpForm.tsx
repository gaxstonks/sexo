'use client';
import React, { useState } from 'react';

export default function SignUpForm(){
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');

  async function handleSubmit(e: React.FormEvent){
    e.preventDefault();
    setMsg('Enviando...');
    const res = await fetch('/api/notify-payment', { method: 'GET' }).catch(()=>null);
    // create account
    const r = await fetch('/api/signup', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await r.json();
    if (r.ok) setMsg('Conta criada! Faça login.');
    else setMsg(data.message || 'Erro ao criar conta');
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input className="w-full border p-2" placeholder="Nome" value={name} onChange={e=>setName(e.target.value)} required />
      <input className="w-full border p-2" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <input className="w-full border p-2" placeholder="Senha" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
      <button className="w-full bg-blue-600 text-white p-2 rounded">Criar conta</button>
      {msg && <p className="text-sm mt-2">{msg}</p>}
    </form>
  );
}
