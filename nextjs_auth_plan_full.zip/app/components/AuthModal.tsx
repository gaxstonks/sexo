'use client';
import React, { useState } from 'react';
import SignUpForm from './SignUpForm';
import LoginForm from './LoginForm';

export default function AuthModal({ onClose }: { onClose?: () => void }) {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  return (
    <div className="fixed inset-0 grid place-items-center bg-black/40 z-50">
      <div className="bg-white p-6 rounded-md w-96">
        <button className="float-right" onClick={onClose}>Fechar</button>
        <h2 className="text-xl font-semibold mb-4">{mode === 'login' ? 'Entrar' : 'Criar conta'}</h2>
        {mode === 'login' ? <LoginForm /> : <SignUpForm />}
        <div className="mt-4">
          <button className="text-sm underline" onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}>
            {mode === 'login' ? 'Criar conta' : 'Já tenho conta'}
          </button>
        </div>
      </div>
    </div>
  );
}
