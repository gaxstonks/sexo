'use client';
import Link from 'next/link';
export default function Nav(){
  return (
    <nav className="bg-gray-50 p-4 border-b">
      <div className="container mx-auto flex justify-between">
        <Link href="/">Home</Link>
        <div className="space-x-4">
          <Link href="/pricing">Planos</Link>
          <Link href="/dashboard">Dashboard</Link>
        </div>
      </div>
    </nav>
  );
}
