import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { prisma } from '../../../lib/prisma';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2022-11-15' });

export async function POST(req: Request) {
  const buf = await req.arrayBuffer();
  const sig = req.headers.get('stripe-signature') || '';
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || '';
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(Buffer.from(buf), sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err);
    return NextResponse.json({ error: 'invalid signature' }, { status: 400 });
  }

  // Handle the checkout.session.completed event to grant plan
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const email = session.customer_details?.email;
    const metadata = session.metadata || {};
    const plan = metadata.plan || 'pro';
    const expiresAt = metadata.expiresAt || null;
    if (email) {
      await prisma.user.updateMany({
        where: { email },
        data: { plan, planActiveUntil: expiresAt ? new Date(expiresAt) : null }
      });
    }
  }

  return NextResponse.json({ received: true });
}
