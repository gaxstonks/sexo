import React from 'react';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../lib/auth';
import { prisma } from '../../lib/prisma';

export default async function Dashboard() {
  const session = await getServerSession(authOptions as any);
  if (!session || !session.user?.email) {
    return (
      <div className="p-8">
        <h1>Não autenticado</h1>
        <p>Por favor faça login.</p>
      </div>
    );
  }
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  const planActive = user?.planActiveUntil ? new Date(user.planActiveUntil) > new Date() : false;

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="mt-2">Olá, {user?.name || user?.email}</p>
      <p className="mt-2">Plano: {user?.plan || 'nenhum'}</p>
      <p className="mt-2">Plano ativo: {planActive ? 'Sim' : 'Não'}</p>
      {planActive ? (
        <div className="mt-4">
          <h2 className="font-semibold">Downloads liberados</h2>
          <ul className="list-disc ml-6">
            <li>Arquivo 1 - <a href="/downloads/file1.zip" className="underline">baixar</a></li>
          </ul>
        </div>
      ) : (
        <div className="mt-4">
          <p>Seu plano não está ativo. <a href="/pricing" className="underline">Veja planos</a></p>
        </div>
      )}
    </div>
  );
}
