# Next.js Auth + Plans Example

This repository includes:
- Next.js (App Router)
- Authentication with NextAuth (Credentials provider)
- Prisma (SQLite) for user storage
- Tailwind CSS basic setup
- Stripe webhook handler (example) to mark plans active
- API route `/api/notify-payment` to programmatically set plan for a user

## Setup (local)

1. Copy `.env.example` to `.env` and set values.
2. Install deps:
   ```bash
   npm install
   ```
3. Generate Prisma client and migrate:
   ```bash
   npx prisma generate
   npx prisma migrate dev --name init
   ```
4. Run dev:
   ```bash
   npm run dev
   ```
5. Open http://localhost:3000

## Notes
- For production use a remote database (Postgres) and secure the secrets.
- Configure Stripe webhook in the Stripe dashboard and set `STRIPE_WEBHOOK_SECRET`.


## Stripe integration

- Create a Checkout Session and include `metadata: { email, plan, expiresAt }`.
- Configure the webhook endpoint to point to `/api/stripe-webhook` and set `STRIPE_WEBHOOK_SECRET`.
- When a session is completed, the webhook will update the user plan in the database.

Example minimal Checkout creation (server-side):

```js
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  payment_method_types: ['card'],
  line_items: [{ price: 'price_XXX', quantity: 1 }],
  success_url: 'https://your-site.com/dashboard',
  cancel_url: 'https://your-site.com/pricing',
  metadata: { email: userEmail, plan: 'pro', expiresAt: new Date(Date.now()+30*24*3600*1000).toISOString() }
});
```
