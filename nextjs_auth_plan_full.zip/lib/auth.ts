import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { prisma } from './prisma';
import bcrypt from 'bcrypt';

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials) return null;
        const user = await prisma.user.findUnique({ where: { email: credentials.email } });
        if (!user || !user.password) return null;
        const isValid = await bcrypt.compare(credentials.password, user.password);
        if (!isValid) return null;
        // return object stored in JWT/session
        return { id: user.id, name: user.name, email: user.email, plan: user.plan, planActiveUntil: user.planActiveUntil };
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.plan = user.plan;
        token.planActiveUntil = user.planActiveUntil ? new Date(user.planActiveUntil).toISOString() : null;
      }
      return token;
    },
    async session({ session, token }) {
      session.user = session.user || {};
      session.user.plan = token.plan;
      session.user.planActiveUntil = token.planActiveUntil;
      return session;
    }
  },
  secret: process.env.NEXTAUTH_SECRET
};

export default NextAuth(authOptions as any);
